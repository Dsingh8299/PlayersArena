package xyz.toors.toors.Notification;

public class MyResponse {
    public int success;
}
