package xyz.toors.toors;

public class ImageSliderModel {
    int Image;

    public ImageSliderModel(int image){
        Image = image;
    }

    public int getImage() {
        return Image;
    }
    public void setImage(int image){
        Image=image;
    }
}
